# 🔍 Code Review Report

## Summary

| Metric | Value |
|--------|-------|
| **Overall Score** | 0/100 |
| **Files Reviewed** | 0 |
| **Critical Issues** | 0 |
| **High Priority Tests** | 0 |
| **Refactoring Opportunities** | 0 |

## 🎯 Top Recommendations

1. 🚨 **Access Error**: Unable to retrieve pull request data. GitHub MCP tools, Bash (gh CLI), and WebFetch tools are currently unavailable. Cannot analyze changed files without access to PR information.
   - Files: 

## 📁 File Details



---

*Generated at 2026-08-26T00:00:00Z • Duration: 0ms*
